const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan'); // Import Morgan
const authRoutes = require('./routes/authRoutes');
const reportRoutes = require('./routes/reportRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const authController = require('./controllers/authController');
const cors = require('cors'); // Import CORS
const path = require('path');
const db = require('./models/db'); // Import database connection

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
    origin: '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE']
})); // Enable CORS
app.use(bodyParser.json());
app.use(morgan('dev')); // Enable Morgan for logging

// Test database connection
db.getConnection()
    .then(connection => {
        console.log('Database connected successfully');
        connection.release();
    })
    .catch(err => {
        console.error('Database connection failed:', err);
    });

// Routes
app.use('/auth', authRoutes);
app.use('/reports', reportRoutes);
app.use('/notifications', notificationRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});